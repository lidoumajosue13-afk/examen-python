# 🚗 Auto-École — Gestion d'une Auto-École en Python

> **Projet académique — Lidouma Josué Dalcy**  
> Module : Programmation Orientée Objet (POO) avancée  
> Institut Supérieur d'Informatique (ISI) — Dakar

---

## 📋 Présentation du projet

Application Python complète de gestion d'une auto-école.  
Elle permet de gérer les **élèves**, les **moniteurs**, le **planning des leçons**,
les **tarifs en FCFA**, la **persistance des données** (JSON/CSV)
et l'**éligibilité des élèves à l'examen du permis**.

---

## 🗂️ Structure du projet

```
autoecole/
│
├── main.py                  ← Application interactive (CLI)
├── demo.py                  ← Démonstration automatique complète
│
├── models/
│   ├── __init__.py          ← Exports du package
│   ├── enums.py             ← CategoriePermis, StatutEleve
│   ├── lecons.py            ← LeconBase (ABC), LeconCode, LeconConduite, LeconExamenBlanc
│   ├── moniteur.py          ← Classe Moniteur
│   ├── eleve.py             ← Classe Eleve (avec planning)
│   └── autoecole.py         ← Classe AutoEcole (agrégation + rapports + persistance)
│
└── exports/                 ← Fichiers générés (JSON, CSV)
    ├── autoecole.json
    ├── eleves_prets_examen.csv
    └── planning_NOM_ID.csv
```

---

## 🏗️ Architecture OOP — Hiérarchie de classes

### 1. Enums (`models/enums.py`)

```python
class CategoriePermis(Enum):
    A = "A"   # Moto          → 10h conduite min
    B = "B"   # Voiture       → 20h conduite min
    C = "C"   # Poids lourd   → 35h conduite min

class StatutEleve(Enum):
    INSCRIT          # Vient de s'inscrire
    EN_FORMATION     # A au moins une leçon
    PRESENTE_EXAMEN  # Présenté à l'examen
    DIPLOME          # A obtenu son permis
```

---

### 2. Hiérarchie des leçons (`models/lecons.py`)

```
LeconBase (ABC)
├── valider()   → méthode abstraite
├── tarif()     → méthode abstraite
│
├── LeconCode          → 5 000 FCFA/heure  │ validée si durée ≥ 1h
├── LeconConduite      → 15 000 FCFA/heure │ validée si durée ≥ 1h
└── LeconExamenBlanc   → 25 000 FCFA fixe  │ validée si durée ≥ 2h
```

**Attributs communs (LeconBase) :**
- `date` — date de la leçon
- `duree` — durée en heures (float)
- `moniteur` — référence au Moniteur encadrant
- `validee` — booléen (calculé par `valider()`)

---

### 3. Classe Moniteur (`models/moniteur.py`)

**Relation : Agrégation** (existe indépendamment de l'auto-école)

| Attribut / Méthode | Description |
|---|---|
| `nom`, `prenom`, `telephone` | Identité du moniteur |
| `planning_hebdomadaire(lecons)` | Rapport par semaine ISO avec total des heures |

---

### 4. Classe Eleve (`models/eleve.py`)

**Relation : Composition** (possède son propre planning)

| Attribut / Méthode | Description |
|---|---|
| `id` | Identifiant unique auto-incrémenté |
| `categorie` | CategoriePermis (A, B ou C) |
| `statut` | StatutEleve (mis à jour automatiquement) |
| `planning` | Liste de LeconBase (composition) |
| `ajouter_lecon(lecon)` | Ajoute + valide la leçon |
| `heures_conduite()` | Total heures LeconConduite |
| `heures_code()` | Total heures LeconCode |
| `est_eligible_examen()` | Vérifie les minimums requis |
| `cout_total_formation()` | Somme des tarifs en FCFA |
| `rapport_eligibilite()` | Rapport détaillé par élève |
| `afficher_planning()` | Affiche toutes les leçons |

---

### 5. Classe AutoEcole (`models/autoecole.py`)

**Chef d'orchestre du projet.**

```python
ae = AutoEcole("Auto-École Liberté", "Libreville")
```

| Méthode | Fonctionnalité |
|---|---|
| `ajouter_moniteur(m)` | Agrégation : ajoute un moniteur existant |
| `inscrire_eleve(e)` | Inscrit un nouvel élève |
| `ajouter_lecon(eleve, lecon)` | Associe une leçon à un élève |
| `rapport_creation()` | Résumé général (F11) |
| `rapport_heures_conduite()` | Barre de progression par élève (F12) |
| `rapport_eligibilite()` | Liste des élèves éligibles (F13) |
| `planning_moniteur(m)` | Planning hebdomadaire (F14) |
| `rapport_couts()` | Coût total par élève + CA total (F15 Bonus) |
| `exporter_json(chemin)` | Sauvegarde complète JSON |
| `importer_json(chemin)` | Rechargement depuis JSON |
| `exporter_csv_planning_eleve(e)` | CSV du planning d'un élève |
| `exporter_csv_eleves_prets()` | CSV des élèves prêts pour l'examen |

---

## 💰 Tarifs (en FCFA)

| Type de leçon | Tarif | Calcul |
|---|---|---|
| **LeconCode** | 5 000 FCFA / heure | `duree × 5 000` |
| **LeconConduite** | 15 000 FCFA / heure | `duree × 15 000` |
| **LeconExamenBlanc** | 25 000 FCFA forfait | Fixe, quelle que soit la durée |

---

## 📏 Heures minimales avant l'examen

| Permis | Catégorie | Code (min) | Conduite (min) |
|---|---|---|---|
| A | Moto | 5h | 10h |
| B | Voiture | 5h | 20h |
| C | Poids lourd | 5h | 35h |

---

## 🛠️ Installation et lancement

### Prérequis
- Python 3.10 ou supérieur (pour les union types)
- Aucune bibliothèque externe requise

### Lancer la démo automatique
```bash
cd autoecole
python demo.py
```

### Lancer l'application interactive
```bash
cd autoecole
python main.py
```

---

## 🖥️ Application interactive (`main.py`)

Au démarrage, l'application demande :
1. Le **nom de l'auto-école**
2. La **ville**
3. Si une sauvegarde JSON existe, propose de la **charger automatiquement**

### Menu principal

```
1. 🧑‍🏫  Gestion des Moniteurs
2. 👤  Gestion des Élèves
3. 📚  Gestion des Leçons
4. 📊  Rapports & Statistiques
5. 💾  Sauvegarde / Chargement
0. ❌  Quitter
```

### Gestion des Moniteurs
- Ajouter un moniteur (nom, prénom, téléphone)
- Lister tous les moniteurs
- Afficher le planning hebdomadaire d'un moniteur

### Gestion des Élèves
- **Inscrire un élève** : nom, prénom, date de naissance, catégorie de permis, téléphone
- Lister tous les élèves avec leur statut
- Voir le planning détaillé d'un élève
- Vérifier son éligibilité à l'examen
- Exporter son planning en CSV

### Gestion des Leçons
- Ajouter une **leçon de code** (5 000 FCFA/h)
- Ajouter une **leçon de conduite** (15 000 FCFA/h)
- Ajouter un **examen blanc** (25 000 FCFA forfait)
- Affiche le tarif calculé avant confirmation
- Voir toutes les leçons de tous les élèves

### Rapports & Statistiques
- Résumé général de l'auto-école
- Heures de conduite par élève avec barre de progression
- Éligibilité à l'examen de tous les élèves
- Planning hebdomadaire par moniteur
- Coût total de formation par élève + chiffre d'affaires global
- Export CSV des élèves prêts pour l'examen

---

## 💾 Persistance des données

### JSON — État complet
```bash
# Sauvegarde
exports/autoecole.json   ← élèves + moniteurs + toutes les leçons

# Rechargement complet à partir du JSON
ae.importer_json("exports/autoecole.json")
```

### CSV — Exports spécifiques
```
exports/planning_NDONG_1.csv        ← planning d'un élève
exports/eleves_prets_examen.csv     ← liste des élèves éligibles
```

---

## 🧪 Fonctionnalités démontrées (`demo.py`)

| N° | Fonctionnalité | Résultat |
|---|---|---|
| F11 | Créer 6 élèves, 2 moniteurs, plusieurs leçons de chaque type | ✅ |
| F12 | Total heures de conduite par élève avec minimum requis | ✅ |
| F13 | Éligibilité à l'examen (heures code + conduite atteintes) | ✅ |
| F14 | Rapport planning hebdomadaire par moniteur (semaines ISO) | ✅ |
| F15 | Coût total de formation + chiffre d'affaires global | ✅ Bonus |
| — | Persistance JSON : export + import avec reconstruction complète | ✅ |
| — | Export CSV planning d'un élève | ✅ |
| — | Export CSV élèves prêts pour l'examen | ✅ |

---

## 🎯 Exemple de résultat — Rapport coûts

```
───────────────────────────────────────────────────────
  COÛT TOTAL DE FORMATION PAR ÉLÈVE
───────────────────────────────────────────────────────
  #1 Marie NDONG                       352,500 FCFA
  #2 Rodrigue ELLA                     352,500 FCFA
  #3 Serge BIVIGOU                     202,500 FCFA
  #4 Carine MOULOUNGUI                 592,500 FCFA
  #5 Jean NZIGOU                       155,000 FCFA
  #6 Fatou KOUMBA                      187,500 FCFA
───────────────────────────────────────────────────────
  💰 CHIFFRE D'AFFAIRES TOTAL : 1,842,500 FCFA
───────────────────────────────────────────────────────
```

---

## 📌 Concepts POO appliqués

| Concept | Application dans le projet |
|---|---|
| **Classe abstraite (ABC)** | `LeconBase` avec `valider()` et `tarif()` abstraits |
| **Héritage** | `LeconCode`, `LeconConduite`, `LeconExamenBlanc` héritent de `LeconBase` |
| **Encapsulation** | Attributs privés `_nom`, `_planning`, etc. avec propriétés |
| **Agrégation** | `AutoEcole` contient des `Moniteur` créés indépendamment |
| **Composition** | `Eleve` crée et possède son propre planning de leçons |
| **Enum** | `CategoriePermis` et `StatutEleve` |
| **Polymorphisme** | `tarif()` et `valider()` différents selon le type de leçon |
| **Persistance** | Sérialisation JSON + export CSV |

---

*Projet Python — ISI Dakar — 2024/2025*
